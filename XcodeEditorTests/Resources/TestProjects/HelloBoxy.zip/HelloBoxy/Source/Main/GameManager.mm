////////////////////////////////////////////////////////////////////////////////
//
//  Jasper Blues
//  Copyright 2012 Jasper Blues
//  All Rights Reserved.
//
//  NOTICE: Jasper Blues permits you to use, modify, and distribute this file
//  in accordance with the terms of the license agreement accompanying it.
//
////////////////////////////////////////////////////////////////////////////////


#import "GameManager.h"
#import "ccMacros.h"

@implementation GameManager

static GameManager* _sharedGameManager = nil;

/* ================================================= Class Methods ================================================== */
+ (GameManager*) sharedGameManager {
    @synchronized ([GameManager class]) {
        if (!_sharedGameManager) {
            [[self alloc] init];
        }
        return _sharedGameManager;
    }
    return nil;
}

/* ================================================ Interface Methods =============================================== */
- (CGSize) getDimensionsOfCurrentScene {
    CGSize screenSize = [[CCDirector sharedDirector] winSize];
    CGSize levelSize;
    levelSize = screenSize;
    return levelSize;
}


@end