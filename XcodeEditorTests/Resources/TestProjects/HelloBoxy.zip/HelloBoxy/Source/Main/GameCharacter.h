////////////////////////////////////////////////////////////////////////////////
//
//  Jasper Blues
//  Copyright 2012 Jasper Blues
//  All Rights Reserved.
//
//  NOTICE: Jasper Blues permits you to use, modify, and distribute this file
//  in accordance with the terms of the license agreement accompanying it.
//
////////////////////////////////////////////////////////////////////////////////

#import <Foundation/Foundation.h>
#import "GameObject.h"

typedef enum {
    kStateSpawning,
    kStateIdle,
    kStateCrouching,
    kStateStandingUp,
    kStateWalking,
    kStateAttacking,
    kStateJumping,
    kStateBreathing,
    kStateTakingDamage,
    kStateDead,
    kStateTraveling,
    kStateRotating,
    kStateDrilling,
    kStateAfterJumping
} CharacterStates;


@interface GameCharacter : GameObject {
    int characterHealth;
    CharacterStates characterState;
}

@property(readwrite) int characterHealth;
@property(readwrite) CharacterStates characterState;

- (void) checkAndClampSpritePosition;

- (int) getWeaponDamage;

- (void) changeState:(CharacterStates)newState;

@end
