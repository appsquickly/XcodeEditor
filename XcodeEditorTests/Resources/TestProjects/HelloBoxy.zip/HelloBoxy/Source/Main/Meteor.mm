////////////////////////////////////////////////////////////////////////////////
//
//  Jasper Blues
//  Copyright 2012 Jasper Blues
//  All Rights Reserved.
//
//  NOTICE: Jasper Blues permits you to use, modify, and distribute this file
//  in accordance with the terms of the license agreement accompanying it.
//
////////////////////////////////////////////////////////////////////////////////

#import "Meteor.h"


@implementation Meteor

/* ================================================== Initializers ================================================== */
- (id) init {
    if ((self = [super init])) {
        gameObjectType = kMeteorType;
        [self setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"meteor.png"]];
    }
    return self;
}

/* ================================================ Interface Methods =============================================== */
- (BOOL) mouseJointBegan {
    //PLAYSOUNDEFFECT(PUZZLE_METEOR);
    return TRUE;
}

@end
