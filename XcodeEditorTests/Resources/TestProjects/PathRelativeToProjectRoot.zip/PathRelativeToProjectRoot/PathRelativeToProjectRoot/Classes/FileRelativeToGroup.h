//
//  FileRelativeToGroup.h
//  PathRelativeToProjectRoot
//
//  Created by Andrew Wooster on 3/13/16.
//  Copyright © 2016 Planetary Scale, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FileRelativeToGroup : NSObject

@end
