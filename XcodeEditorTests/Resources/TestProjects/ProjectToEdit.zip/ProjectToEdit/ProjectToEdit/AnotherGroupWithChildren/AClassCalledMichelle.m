////////////////////////////////////////////////////////////////////////////////
//
//  APPSQUICKLY
//  Copyright 2015 appsquickly Pty Ltd
//  All Rights Reserved.
//
//  NOTICE: Prepared by AppsQuick.ly on behalf of appsquickly. This software
//  is proprietary information. Unauthorized use is prohibited.
//
////////////////////////////////////////////////////////////////////////////////

#import "AClassCalledMichelle.h"


@implementation AClassCalledMichelle
{

}
@end