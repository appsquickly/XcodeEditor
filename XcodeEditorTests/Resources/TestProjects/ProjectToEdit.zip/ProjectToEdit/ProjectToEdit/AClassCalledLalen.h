//
//  AClassCalledLalen.h
//  ProjectToEdit
//
//  Created by Jasper Blues on 22/11/2015.
//  Copyright © 2015 appsquickly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AClassCalledLalen : NSObject

@end
