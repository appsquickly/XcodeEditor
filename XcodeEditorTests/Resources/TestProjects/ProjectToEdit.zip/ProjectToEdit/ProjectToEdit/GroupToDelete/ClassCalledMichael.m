#import "ClassCalledMichael.h"


@implementation ClassCalledMichael
{

}
@end