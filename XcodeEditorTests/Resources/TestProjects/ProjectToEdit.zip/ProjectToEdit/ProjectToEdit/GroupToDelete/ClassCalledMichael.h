#import <Foundation/Foundation.h>


@interface ClassCalledMichael : NSObject
@end