#import <Foundation/Foundation.h>


@interface ClassCalledGavin : NSObject
@end