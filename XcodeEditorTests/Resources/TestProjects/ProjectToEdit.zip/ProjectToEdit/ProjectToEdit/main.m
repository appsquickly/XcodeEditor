//
//  main.m
//  ProjectToEdit
//
//  Created by Jasper Blues on 21/11/2015.
//  Copyright © 2015 appsquickly. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
