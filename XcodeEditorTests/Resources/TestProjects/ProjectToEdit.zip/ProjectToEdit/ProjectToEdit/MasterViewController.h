//
//  MasterViewController.h
//  ProjectToEdit
//
//  Created by Jasper Blues on 21/11/2015.
//  Copyright © 2015 appsquickly. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;

@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;


@end

