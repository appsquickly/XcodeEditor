#!/bin/sh
rm -fr /Developer/Library/Frameworks/expanzIOS.framework
rm -fr /Developer/Library/Xcode/Templates/expanz
rm -fr  ~/Library/Developer/Xcode/Templates/expanz
