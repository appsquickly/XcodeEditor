#!/bin/sh
cd /Developer/Library/Frameworks
rm -fr expanziOS.framework
sudo ln -s /Developer/expanz/Frameworks/expanziOS.framework expanziOS.framework

