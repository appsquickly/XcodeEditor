////////////////////////////////////////////////////////////////////////////////
//
//  EXPANZ
//  Copyright 2008-2011 EXPANZ
//  All Rights Reserved.
//
//  NOTICE: Expanz permits you to use, modify, and distribute this file
//  in accordance with the terms of the license agreement accompanying it.
//
////////////////////////////////////////////////////////////////////////////////
#import "TestFixture_ViewController.h"


@implementation TestFixture_ViewController

@synthesize ResultLabel = _ResultLabel;
@synthesize Op1Label = _Op1Label;
@synthesize Op2Label = _Op2Label;
@synthesize Result = _ResultField;
@synthesize Op1 = _Op1Field;
@synthesize Op2 = _Op2Field;
@synthesize add = _add;
@synthesize subtract = _subtract;
@synthesize multiply = _multiply;
@synthesize divide = _divide;
@synthesize customersList = _customersList;



@end