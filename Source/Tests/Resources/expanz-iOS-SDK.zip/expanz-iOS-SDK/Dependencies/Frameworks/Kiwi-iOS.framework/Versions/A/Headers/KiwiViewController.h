//
// Licensed under the terms in License.txt
//
// Copyright 2010 Allen Ding. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KiwiViewController : UIViewController

@end

