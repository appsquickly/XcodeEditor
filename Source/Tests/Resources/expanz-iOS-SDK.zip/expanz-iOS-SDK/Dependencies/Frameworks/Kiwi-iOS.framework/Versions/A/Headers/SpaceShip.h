//
// Licensed under the terms in License.txt
//
// Copyright 2010 Allen Ding. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SpaceShip : NSObject

#pragma mark -
#pragma mark Managing Shields

- (BOOL)raiseShields;

@end
