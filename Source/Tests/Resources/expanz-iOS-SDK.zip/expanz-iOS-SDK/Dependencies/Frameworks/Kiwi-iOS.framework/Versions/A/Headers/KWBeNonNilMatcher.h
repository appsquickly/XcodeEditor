//
//  KWBeNotNilMatcher.h
//  Kiwi
//
//  Created by Luke Redpath on 17/01/2011.
//  Copyright 2011 Allen Ding. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KWMatcher.h"

@interface KWBeNonNilMatcher : KWMatcher {

}
- (void)beNonNil;
@end
