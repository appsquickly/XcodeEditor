#import "NSObject+Objection.h"


@implementation NSObject(JSObjection)
- (void)awakeFromObjection 
{
  
}
@end
