#import <Foundation/Foundation.h>

@interface NSObject(JSObjection)
- (void)awakeFromObjection;
@end
