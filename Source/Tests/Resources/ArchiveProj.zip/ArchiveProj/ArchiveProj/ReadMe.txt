This file will describe how to set up a new project.
