//
//  SCArchiveProjViewController.h
//  ArchiveProj
//
//  Created From Module Template
//  By Janine Ohmer on 6/12/12
//  Copyright (c) 2012 furfly, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFModuleViewController.h"

@interface SCArchiveProjViewController : AFModuleViewController
{
}

@end
