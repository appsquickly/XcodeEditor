//
//  SCArchiveProj.m
//  ArchiveProj
//
//  Created From Module Template
//  By Janine Ohmer on 6/12/12
//  Copyright (c) 2012 furfly, LLC. All rights reserved.
//

#import "SCArchiveProj.h"

@implementation SCArchiveProj

+ (NSString*)defaultUTI
{
	// Module's default UTI (does not require customization if only one instance of the module will be installed)
	return @"com.synapticats.archiveproj";
}


//- (AFModuleViewController *)makeRootViewController
//{
//	// You can override this method to provide an alternate view controller, such as a view controller for another module, thereby using the interface from another
//	// module as the interface for this module.
//	
//	// For example:
//	AFModule <SomeModuleProtocol> *someModule = (AFModule <SomeModuleProtocol> *)[[AFModuleManager sharedManager] moduleConformingToProtocol:@protocol(SomeModuleProtocol)];
//	AFModuleViewController *controller = [someModule makeRootViewController];
//	controller.owningModule = self; // This module must be the owning module of the controller for everything in the platform to work correctly
//	return controller;
//}


#pragma mark Observation methods for this module

//- (void)didInstall
//{
//	// Do something when this module is installed.
//}


//- (void)willUninstall
//{
//	// Do something when this module is uninstalled.
//}


//- (void)willLaunchWithContext:(AFLaunchContext*)launchContext
//{
//	// Do something when this module launches.
//}


//- (void)willTerminate
//{
//	// Do something when this module terminates.
//}


//- (void)didCreateViewController:(UIViewController*)viewController
//{
//	// Do something when a view controller for this module is created.
//}


//- (void)willDestroyViewController:(UIViewController*)viewController
//{
//	// Do something when a view controller for this module is destroyed.
//}


//- (void)viewControllerWillAppear:(UIViewController*)viewController
//{
//	// Do something when a view controller for this module is about to appear.
//}


//- (void)viewControllerDidAppear:(UIViewController*)viewController
//{
//	// Do something when a view controller for this module did appear.
//}


//- (void)viewControllerWillDisppear:(UIViewController*)viewController
//{
//	// Do something when a view controller for this module is about to disappear.
//}


#pragma mark Observation methods for other modules

//- (void)observedModuleDidInstall:(AFModule*)module
//{
//	// Do something when module is installed.
//}


//- (void)observedModuleWillUninstall:(AFModule*)module
//{
//	// Do something when module is uninstalled.
//}


//- (void)observedModule:(AFModule*)module willLaunchWithContext:(AFLaunchContext*)launchContext
//{
//	// Do something when module is about to launch.
//}


//- (void)observedModuleWillTerminate:(AFModule*)module
//{
//	// Do something when module is about to terminate.
//}


//- (void)observedModule:(AFModule*)module didCreateViewController:(UIViewController*)viewController
//{
//	// Do something when a view controller for module is about to be created.
//}


//- (void)observedModule:(AFModule*)module willDestroyViewController:(UIViewController*)viewController
//{
//	// Do something when a view controller for module is about to be destroyed.
//}


//- (void)observedModule:(AFModule*)module viewControllerWillAppear:(UIViewController*)viewController
//{
//	// Do something when a view controller for module is about to appear.
//}


//- (void)observedModule:(AFModule*)module viewControllerDidAppear:(UIViewController*)viewController
//{
//	// Do something when a view controller for module did appear.
//}


//- (void)observedModule:(AFModule*)module viewControllerWillDisppear:(UIViewController*)viewController
//{
//	// Do something when a view controller for module is about to disappear.
//}


#pragma mark Observation methods for the application

//- (void)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)launchOptions
//{
//	// Do something when the application finishes launching.
//}


//- (BOOL)application:(UIApplication*)application handleOpenURL:(NSURL*)url
//{
//	// If this module can handle the opening of a remote URL, handle it and return YES.
//}


//- (BOOL)application:(UIApplication*)application openURL:(NSURL*)url sourceApplication:(NSString*)sourceApplication annotation:(id)annotation
//{
//	// If this module can handle the opening of a remote URL from another application, handle it and return YES.
//}


//- (void)applicationDidBecomeActive:(UIApplication*)application
//{
//	// Do something when the application becomes active.
//}


//- (void)applicationWillResignActive:(UIApplication*)application
//{
//	// Do something when the application will no longer be active.
//}


//- (void)applicationDidReceiveMemoryWarning:(UIApplication*)application
//{
//	// Do something when the application receives a memory warning.
//}


//- (void)applicationWillTerminate:(UIApplication*)application
//{
//	// Do something when the app is about to terminate.
//}


//- (void)applicationSignificantTimeChange:(UIApplication*)application
//{
//	// Do something when a significant time change (such as the arrival of midnight, an update of the time by a carrier, and the change to daylight savings time).
//}


//- (void)application:(UIApplication*)application willChangeStatusBarOrientation:(UIInterfaceOrientation)newStatusBarOrientation duration:(NSTimeInterval)duration
//{
//	// Do something when the status bar orientation is about to change.
//}


//- (void)application:(UIApplication*)application didChangeStatusBarOrientation:(UIInterfaceOrientation)oldStatusBarOrientation
//{
//	// Do something after the orientation of the status bar has changed.
//}


//- (void)application:(UIApplication*)application willChangeStatusBarFrame:(CGRect)newStatusBarFrame
//{
//	// Do something when the status bar frame is about to change.
//}


//- (void)application:(UIApplication*)application didChangeStatusBarFrame:(CGRect)oldStatusBarFrame
//{
//	// Do something when the frame of the status bar has changed.
//}


//- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
//{
//	// Do something when the application finishes registering remote notifications.
//}


//- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
//{
//	// Do something when the application fails to register for remote notifications.
//}


//- (void)application:(UIApplication*)application didReceiveRemoteNotification:(NSDictionary*)userInfo
//{
//	// Do something when the app receives a remote notification.
//}


//- (void)application:(UIApplication*)application didReceiveLocalNotification:(UILocalNotification*)notification
//{
//	// Do something when the app receives a local notification.
//}


//- (void)applicationDidEnterBackground:(UIApplication*)application
//{
//	// Do something after the app enters the background.
//}


//- (void)applicationWillEnterForeground:(UIApplication*)application
//{
//	// Do something when the app is about to enter the foreground.
//}


//- (void)applicationProtectedDataWillBecomeUnavailable:(UIApplication*)application
//{
//	// Do something when the protected data for this application is about to become unavailable.
//}


//- (void)applicationProtectedDataDidBecomeAvailable:(UIApplication*)application
//{
//	// Do something when the protected data for this application is about to become available.
//}

@end
