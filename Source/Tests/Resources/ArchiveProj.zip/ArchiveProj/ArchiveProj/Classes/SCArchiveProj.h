//
//  SCArchiveProj.h
//  ArchiveProj
//
//  Created From Module Template
//  By Janine Ohmer on 6/12/12
//  Copyright (c) 2012 furfly, LLC. All rights reserved.
//

#import "AFModule.h"

@interface SCArchiveProj : AFModule

@end

