//
//  SCArchiveProjViewController.m
//  ArchiveProj
//
//  Created From Module Template
//  By Janine Ohmer on 6/12/12
//  Copyright (c) 2012 furfly, LLC. All rights reserved.
//

#import "SCArchiveProjViewController.h"

#import "AFModuleManager.h"

@implementation SCArchiveProjViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)dealloc
{
    [super dealloc];
}

//- (BOOL)autoStylePrimaryView
//{
//	// Return NO if you do not want this view to be autostyled by the framework.
//}


//- (void)willPopViewController
//{
//	// Called when this view controller is about to be popped in response to the back button being touched.
//}


//- (void)launchedWithContext
//{
//	// Called when the module is launched or re-launched with a new context.
//}

@end
