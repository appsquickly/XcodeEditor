//
//  SCArchiveProjTests.m
//  SCArchiveProjTests
//
//  Created by Janine Ohmer on 6/12/12.
//  Copyright (c) 2012 furfly, LLC. All rights reserved.
//

#import "SCArchiveProjTests.h"

@implementation SCArchiveProjTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in SCArchiveProjTests");
}

@end
