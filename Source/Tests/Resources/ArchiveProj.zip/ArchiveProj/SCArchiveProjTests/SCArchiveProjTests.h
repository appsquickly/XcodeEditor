//
//  SCArchiveProjTests.h
//  SCArchiveProjTests
//
//  Created by Janine Ohmer on 6/12/12.
//  Copyright (c) 2012 furfly, LLC. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SCArchiveProjTests : SenTestCase

@end
